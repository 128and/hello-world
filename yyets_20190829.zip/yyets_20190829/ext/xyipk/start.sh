#!/bin/bash

curr_dir=$(cd `dirname $0`; pwd)
sys_dir="${curr_dir}/../system"
tmp_dir="/tmp/.xyapp"
log_file="${tmp_dir}/xyipk.log"

mon_name="xyipk_monitor"
mon_path="${curr_dir}/${mon_name}"

export PATH=${PATH}:"${curr_dir}/bin"

if [ ! -f ${tmp_dir} ]; then
	mkdir -p ${tmp_dir}
fi

log()
{
	local time=`date "+%Y-%m-%d %H:%M:%S"`
	echo "${time} <pid $$> $*" >> ${log_file}
}


cfg_file="/tmp/.xyipkcfg.json"

if [ ! -f $cfg_file ]; then
	log "cfg file is not exist $cfg_file"
	exit 1
fi

valid_cfg()
{
	local v=`jg "$1" $cfg_file`
	if [ -z "$v" ]; then
		log "config $1 is nul"
		exit 1
	fi
}

valid_cfg "CacheDir"
valid_cfg "Hostname"

monitor_pids=`ps -ef | grep ${mon_name} | grep -v grep | awk '{ printf $2 " " }'`

if [ -z "${monitor_pids}" ]; then
	# start monitor
	log "start xyipk monitor"
	${mon_path} > /dev/null 2>&1 &
fi

