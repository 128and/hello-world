#!/bin/bash

curr_dir=$(cd `dirname $0`; pwd)

mon_name="xyipk_monitor"
mon_path="${curr_dir}/${mon_name}"
exe_full_name="${curr_dir}/bin/xyipk"

status_xyipk()
{
	local monitor_pids=`ps -ef | grep ${mon_name} | grep -v grep | awk '{ printf $2 " " }'`
	if [ -n "${monitor_pids}" ]; then
		echo "${monitor_pids}"
	fi
	
	local exe_pids=`ps -ef | grep ${exe_full_name} | grep -v grep | awk '{ printf $2 " " }'`
	if [ -n "${exe_pids}" ]; then
		echo "${exe_pids}"
	fi
}

status_xyipk
