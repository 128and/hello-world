#!/bin/bash

curr_dir=$(cd `dirname $0`; pwd)
sys_dir="${curr_dir}/../system"
tmp_dir="/tmp/.xyapp"
log_file="${tmp_dir}/xyipk.log"

log()
{
	local time=`date "+%Y-%m-%d %H:%M:%S"`
	echo "${time} <pid $$> $*" >> ${log_file}
}

log "clean plugins"

clean_plugins()
{
	for d in ${sys_dir}/miner.*.ipk
	do
		log "stop plugin ${d}"
		sh ${d}/stop.sh
		if [ -f "${d}/clean.sh" ]; then
			log "clean plugin ${d}"
			${d}/clean.sh
		fi
		log "remove plugin ${d}"
		rm -rf ${d}
	done
	
	log "remove ipk control dir"
	rm -rf ${sys_dir}/usr/lib/opkg
}

clean_plugins
